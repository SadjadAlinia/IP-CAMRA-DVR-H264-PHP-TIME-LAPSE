插件说明：
1、web.cab是支持h264视频的IE插件；
2、web_H265.cab是支持h265视频的IE插件。