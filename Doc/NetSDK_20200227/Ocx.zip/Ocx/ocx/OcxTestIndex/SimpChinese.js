﻿var Translate=
{
	title:"硬盘录像机",
	usr:"用户名",
	pswd:"密码",
	logi:"请登录!",
	login:"登录",
	ch:"通道",
	MFt:"主码流",
	SFt:"辅码流",
	Zoom:"变倍",
	Iris:"光圈",
	Focu:"聚焦",
	Split1:"一画面",
	Split4:"四画面",
	Split9:"九画面",
	Split16:"十六画面",
	Split25:"二十五画面",
	Split36:"三十六画面",
	PlayAll:"全通道播放",
	StopPlayAll:"关闭全通道",
	mainPlayAll:"全播放（主码流）",
	subPlayAll:"全播放（辅码流）",
	ok:"确定",
	Cancel:"取消",
	logout:"退出",
	autoPrompt:"自动提示",
	version:"版本"
	
	
	
}
var Versions=
{
    vidioIn:"视频输入：",
    audioIn:"音频输入：",
    alarmIn:"报警输入：",
    alarmOut:"报警输出：",
    buildTime:"发布日期：",
    version:"系统版本：",
    serialNo:"序列号：",
    ok:"好"
  
}
 



